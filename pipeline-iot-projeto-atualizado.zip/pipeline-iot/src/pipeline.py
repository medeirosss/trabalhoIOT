"""Importa CSV de temperatura IoT, normaliza dados e cria três views."""
import argparse
import sys
from pathlib import Path
import pandas as pd
from sqlalchemy import text
from common import get_engine

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = """
CREATE TABLE IF NOT EXISTS temperature_readings (
    id BIGSERIAL PRIMARY KEY,
    device_id TEXT NOT NULL,
    recorded_at TIMESTAMP NOT NULL,
    temperature DOUBLE PRECISION NOT NULL,
    location TEXT,
    source_row BIGINT NOT NULL UNIQUE
);
CREATE INDEX IF NOT EXISTS idx_temp_device ON temperature_readings(device_id);
CREATE INDEX IF NOT EXISTS idx_temp_time ON temperature_readings(recorded_at);
"""

def select_column(df, options):
    by_name = {str(c).strip().lower().replace(" ", "_"): c for c in df.columns}
    for candidate in options:
        if candidate in by_name:
            return by_name[candidate]
    return None

def normalize(df):
    time_col = select_column(df, ["noted_date", "recorded_at", "timestamp", "datetime", "date", "time"])
    temp_col = select_column(df, ["temp", "temperature", "temperature_c", "temperature_celsius"])
    device_col = select_column(df, ["device_id", "device", "sensor_id", "sensor", "room_id/id", "room_id", "id"])
    loc_col = select_column(df, ["out/in", "location", "room", "status"])
    if time_col is None or temp_col is None:
        raise ValueError(f"CSV incompatível. Colunas encontradas: {list(df.columns)}. São necessárias data/hora e temperatura.")
    raw_time = df[time_col].astype('string').str.strip()
    # Kaggle 'Temperature Readings: IoT Devices' geralmente usa DD-MM-YYYY HH:MM.
    timestamps = pd.to_datetime(raw_time, format="%d-%m-%Y %H:%M", errors="coerce")
    missing = timestamps.isna()
    if missing.any():
        timestamps.loc[missing] = pd.to_datetime(raw_time.loc[missing], errors="coerce", dayfirst=True)
    temps = pd.to_numeric(df[temp_col].astype('string').str.replace(',', '.', regex=False), errors='coerce')
    if device_col is None:
        devices = pd.Series('sensor_geral', index=df.index, dtype='string')
    else:
        devices = df[device_col].astype('string').fillna('desconhecido')
    # No dataset Kaggle, room_id/id é constante; In/Out identifica pontos de medição,
    # não dispositivos físicos individualizados. Separar os canais para comparação.
    if loc_col is not None and str(loc_col).lower() == 'out/in':
        devices = devices + ' | ' + df[loc_col].astype('string').fillna('Indefinido')
    result = pd.DataFrame({
        'device_id': devices.astype(str),
        'recorded_at': timestamps,
        'temperature': temps,
        'location': df[loc_col].astype('string') if loc_col else None,
        'source_row': df.index + 1,
    })
    return result.dropna(subset=['recorded_at','temperature'])

def import_csv(csv_path, chunksize=10000):
    engine = get_engine()
    with engine.begin() as conn:
        for statement in SCHEMA.strip().split(';'):
            if statement.strip(): conn.execute(text(statement))
    processed, valid = 0, 0
    for raw in pd.read_csv(csv_path, chunksize=chunksize, low_memory=False):
        raw.index = range(processed, processed + len(raw))
        processed += len(raw)
        frame = normalize(raw)
        valid += len(frame)
        if frame.empty: continue
        # Reimportação idempotente: registros de origem já existentes são ignorados.
        with engine.begin() as conn:
            rows = frame.where(pd.notnull(frame), None).to_dict('records')
            stmt = text("""INSERT INTO temperature_readings
                (device_id,recorded_at,temperature,location,source_row)
                VALUES (:device_id,:recorded_at,:temperature,:location,:source_row)
                ON CONFLICT (source_row) DO UPDATE SET
                device_id=EXCLUDED.device_id, recorded_at=EXCLUDED.recorded_at,
                temperature=EXCLUDED.temperature, location=EXCLUDED.location""")
            conn.execute(stmt, rows)
        print(f'Processadas {processed} linhas...')
    sql = (ROOT/'sql'/'views.sql').read_text(encoding='utf-8')
    with engine.begin() as conn:
        for statement in sql.split(';'):
            if statement.strip(): conn.execute(text(statement))
        total = conn.execute(text('SELECT COUNT(*) FROM temperature_readings')).scalar_one()
    print(f'Concluído: {processed} linhas lidas, {valid} válidas, {processed-valid} descartadas; {total} registros no banco.')

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--csv',type=Path,default=None,help='Caminho para CSV; por padrão detecta um único CSV em data/')
    args=parser.parse_args()
    if args.csv:
        path=args.csv
    else:
        csvs=list((ROOT/'data').glob('*.csv'))
        if len(csvs)!=1:
            sys.exit('Coloque exatamente um CSV em data/ ou passe --csv CAMINHO_DO_ARQUIVO')
        path=csvs[0]
    if not path.exists(): sys.exit(f'CSV não encontrado: {path}')
    import_csv(path)
