import pandas as pd
import plotly.express as px
import streamlit as st
from sqlalchemy import text
from common import get_engine

st.set_page_config(page_title='Dashboard de Temperaturas IoT',layout='wide')
st.title('Dashboard de Temperaturas IoT')
st.caption('Análise histórica de leituras de sensores IoT armazenadas no PostgreSQL')

@st.cache_data(ttl=60)
def load_data(view):
    allowed={'avg_temp_por_dispositivo','leituras_por_hora','temp_max_min_por_dia'}
    if view not in allowed: raise ValueError('View inválida')
    with get_engine().connect() as conn:
        return pd.read_sql(text(f'SELECT * FROM {view}'),conn)

try:
    avg=load_data('avg_temp_por_dispositivo')
    hours=load_data('leituras_por_hora')
    daily=load_data('temp_max_min_por_dia')
except Exception as exc:
    st.error('Não foi possível consultar o PostgreSQL. Inicie o Docker e execute o pipeline antes de abrir o dashboard.')
    st.exception(exc)
    st.stop()

if avg.empty:
    st.warning('Ainda não há leituras importadas.')
    st.stop()

c1,c2,c3=st.columns(3)
c1.metric('Pontos de medição',len(avg))
c2.metric('Leituras',f"{int(avg['total_leituras'].sum()):,}".replace(',','.'))
c3.metric('Dias registrados',len(daily))

st.info('O CSV identifica uma única sala (Room Admin) e dois pontos de medição: In (interno) e Out (externo). Eles não representam necessariamente dois dispositivos físicos.')
st.subheader('Média de temperatura por ponto de medição')
st.plotly_chart(px.bar(avg.sort_values('avg_temp',ascending=False),x='device_id',y='avg_temp',labels={'device_id':'Ponto de medição','avg_temp':'Temperatura média (°C)'}),use_container_width=True)
st.subheader('Leituras por hora do dia')
st.plotly_chart(px.line(hours.sort_values('hora'),x='hora',y='contagem',markers=True,labels={'hora':'Hora','contagem':'Quantidade de leituras'}),use_container_width=True)
st.subheader('Temperaturas máximas e mínimas por dia')
st.plotly_chart(px.line(daily,x='data',y=['temp_max','temp_min'],labels={'data':'Data','value':'Temperatura (°C)','variable':'Série'}),use_container_width=True)
with st.expander('Dados consolidados das views'):
    st.dataframe(avg,use_container_width=True)
    st.dataframe(hours,use_container_width=True)
    st.dataframe(daily,use_container_width=True)
