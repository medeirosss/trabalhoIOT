# Relatório técnico — Pipeline de Dados com IoT e Docker

> MODELO A COMPLETAR APÓS A EXECUÇÃO. Não apresentar testes ou resultados como realizados antes de validá-los.

## 1. Contextualização

O projeto implementa um pipeline para processar leituras históricas de temperatura de dispositivos IoT, armazená-las em PostgreSQL e disponibilizar indicadores analíticos em um dashboard web.

## 2. Tecnologias e arquitetura

Dataset Kaggle (CSV) → Python/Pandas → PostgreSQL 16 em Docker → três views SQL → Streamlit/Plotly.

## 3. Procedimento de implantação

Descrever instalação de dependências, inicialização `docker compose up -d --wait`, execução do pipeline e abertura do dashboard. Registrar versões efetivamente utilizadas.

## 4. Tratamento e ingestão

Informar quantidade de linhas lidas, válidas e descartadas conforme saída real do pipeline. Explicar conversão de datas e temperaturas.

## 5. Views SQL

- `avg_temp_por_dispositivo`: temperatura média e quantidade de leituras por ponto de medição (In/Out).
- `leituras_por_hora`: contagem por hora do dia.
- `temp_max_min_por_dia`: máxima, mínima e média por data.

## 6. Dashboard — capturas reais

INSERIR print do gráfico 1.

INSERIR print do gráfico 2.

INSERIR print do gráfico 3.

## 7. Insights obtidos

Análise exploratória diretamente no CSV (antes do teste do PostgreSQL): 97.606 registros, 86 datas com leituras, período de 28/07/2018 a 08/12/2018. A categoria interna (In) apresenta 20.345 leituras e média 30,45 °C; a externa (Out), 77.261 leituras e média 36,27 °C. A diferença entre médias é de aproximadamente 5,81 °C. O campo de sala é constante (`Room Admin`), então não há identificação inequívoca de dois dispositivos físicos. Após executar: confirmar estes números no banco e inserir capturas dos gráficos reais. Relacionar possíveis aplicações a monitoramento de temperatura, qualidade de dados e planejamento de manutenção.

## 8. Conclusão

Resumir o que foi implementado e as limitações: dados históricos, ausência de sensores conectados em tempo real e dependência da qualidade do CSV.

## 9. Evidências e referências

Adicionar URL do GitHub, URL do vídeo e referência ao dataset Kaggle.
