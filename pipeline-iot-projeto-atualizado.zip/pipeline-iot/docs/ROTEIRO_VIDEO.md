# Roteiro de vídeo pitch (até 4 minutos)

- 0:00–0:35 — Apresentação do problema e objetivo.
- 0:35–1:15 — Mostrar estrutura do repositório, Docker Compose, Python, PostgreSQL e Streamlit.
- 1:15–1:50 — Demonstrar importação real do CSV e contagem de registros.
- 1:50–3:20 — Mostrar os três gráficos e explicar o significado de cada view SQL.
- 3:20–3:50 — Apresentar insights observados e aplicações práticas.
- 3:50–4:00 — Encerramento e indicação do GitHub.

A gravação precisa mostrar o dashboard realmente funcionando. Não usar capturas simuladas como evidência.
