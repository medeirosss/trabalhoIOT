# Análise do CSV real (sem execução do Docker)

Fonte: IOT-temp.csv enviado pelo aluno, originário do dataset Kaggle indicado no enunciado.

| Métrica | Resultado |
|---|---:|
| Linhas | 97.606 |
| Colunas | 5 |
| Datas com registros | 86 |
| Primeiro registro cronológico | 28/07/2018 07:06 |
| Último registro cronológico | 08/12/2018 09:30 |
| Leituras In | 20.345 |
| Média In | 30,45 °C |
| Mínima/máxima In | 21 / 41 °C |
| Leituras Out | 77.261 |
| Média Out | 36,27 °C |
| Mínima/máxima Out | 24 / 51 °C |
| Valores nulos | 0 |
| Datas inválidas | 0 |
| IDs de origem repetidos | 1 |

**Interpretação:** `room_id/id` só contém `Room Admin`. `out/in` identifica duas categorias de medição, e não permite afirmar quantos sensores físicos existiam. Para a view de média por dispositivo solicitada no trabalho, o pipeline utiliza os pontos lógicos `Room Admin | In` e `Room Admin | Out`, explicando essa limitação no dashboard.

**Evidência:** os resultados acima são da inspeção direta do CSV. A validação PostgreSQL/Docker/Streamlit e as capturas reais continuam pendentes.
