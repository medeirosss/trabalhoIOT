import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import pandas as pd
from pipeline import normalize

def test_kaggle_columns():
    df=pd.DataFrame({'id':[1,2], 'room_id/id':['Room A','Room B'], 'noted_date':['08-12-2018 09:30','08-12-2018 10:30'], 'temp':[29.5,30], 'out/in':['In','Out']})
    result=normalize(df)
    assert len(result)==2
    assert result['device_id'].tolist()==['Room A | In','Room B | Out']
    assert result['recorded_at'].dt.hour.tolist()==[9,10]

def test_invalid_temp_discarded():
    df=pd.DataFrame({'noted_date':['08-12-2018 09:30'], 'temp':['bad']})
    assert normalize(df).empty

def test_real_dataset_shape():
    path=Path(__file__).resolve().parents[1]/'data'/'IOT-temp.csv'
    if path.exists():
        df=pd.read_csv(path, nrows=50)
        assert list(df.columns)==['id','room_id/id','noted_date','temp','out/in']
        assert len(normalize(df))==50
