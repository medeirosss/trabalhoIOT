# Pipeline de Dados com IoT e Docker

Projeto acadêmico: ingestão de leituras históricas de temperatura IoT, armazenamento PostgreSQL em Docker, três views SQL e dashboard interativo Streamlit/Plotly.

## Arquitetura

CSV Kaggle → Python/Pandas → PostgreSQL (Docker Compose) → Views SQL → Streamlit/Plotly.

## Requisitos

- Windows com PowerShell, Python 3.10+ e Docker Desktop (Linux containers)
- Git para publicação no GitHub
- Dataset [Temperature Readings: IoT Devices](https://www.kaggle.com/datasets/atulanandjha/temperature-readings-iot-devices)

## Execução (Windows)

1. O pacote de entrega já contém `data/IOT-temp.csv`. Caso obtenha o projeto pelo GitHub, baixe o CSV do Kaggle e coloque-o em `data/` (o CSV não é versionado).
2. No PowerShell, abra a pasta do projeto e execute `powershell -ExecutionPolicy Bypass -File .\run.ps1`.
3. O script instala dependências no ambiente virtual, inicia PostgreSQL, importa o CSV, cria as views e abre o dashboard.
4. Abra a URL local exibida pelo Streamlit (normalmente `http://localhost:8501`).
5. Para parar o banco: `docker compose down` (preserva o volume). Para apagar os dados: `docker compose down -v` (destrutivo).

Se a porta 5433 estiver ocupada, altere `POSTGRES_PORT` em `.env`. Não publique `.env` no GitHub.

## Execução manual

```powershell
Copy-Item .env.example .env
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
docker compose up -d --wait
.\.venv\Scripts\python.exe src/pipeline.py
.\.venv\Scripts\python.exe -m streamlit run src/dashboard.py
```

## Estrutura

- `src/pipeline.py`: lê o CSV em lotes, normaliza data, temperatura e identificação, cria a tabela e importa os registros.
- `src/dashboard.py`: consulta as três views e mostra os gráficos.
- `src/common.py`: configura conexão PostgreSQL com variáveis de ambiente.
- `sql/views.sql`: views analíticas.
- `docker-compose.yml`: banco PostgreSQL 16 e volume persistente.
- `docs/`: roteiro do relatório e capturas após execução real.

## Views SQL

1. `avg_temp_por_dispositivo`: média de temperatura e número de leituras por ponto de medição (Room Admin | In / Out).
2. `leituras_por_hora`: quantidade de leituras agrupadas pela hora do dia (0–23).
3. `temp_max_min_por_dia`: temperaturas máxima, mínima e média por data.

## Dados e limites

O dataset real possui 97.606 linhas, 86 dias com leituras, uma sala (`Room Admin`) e dois pontos (`In` e `Out`). Os pontos não são identificadores inequívocos de sensores físicos. A importação tenta reconhecer `noted_date`, `temp`, `room_id/id`, `id` e `out/in`, bem como variantes comuns. Caso não haja identificador, usa `sensor_geral`. Valores inválidos de data ou temperatura são descartados e contabilizados. Os dados são históricos, não uma telemetria em tempo real. `source_row` é usado para evitar duplicação na reimportação do mesmo arquivo; se trocar o CSV, remova o volume para reinicializar a base.

**Atenção:** o projeto precisa ser validado com o CSV real e o Docker antes da entrega. Os prints e conclusões só devem ser produzidos após essa execução.

## Git / GitHub

```powershell
git init
git branch -M main
git add .
git commit -m "Pipeline IoT com Docker, PostgreSQL e Streamlit"
git remote add origin https://github.com/SEU_USUARIO/pipeline-iot.git
git push -u origin main
# Para atualizar depois:
git pull --rebase origin main
git push
```

O `.gitignore` exclui o CSV e as credenciais locais; o link de origem do dataset é fornecido acima.

## Capturas e vídeo

Após validar, salve prints dos três gráficos em `docs/screenshots/` e inclua-os no README e relatório. Grave um vídeo de até quatro minutos mostrando o pipeline, tecnologias, dashboard e conclusões. Publique como público ou não listado e confira o link.

## Análise prévia do CSV (sem execução do PostgreSQL)

- 97.606 registros, cinco colunas, sem valores nulos nem datas inválidas.
- Período: 28/07/2018 a 08/12/2018, com leituras em 86 datas distintas.
- In: 20.345 leituras, média 30,45 °C; Out: 77.261 leituras, média 36,27 °C.
- Uma identificação `id` duplicada no arquivo de origem; cada linha é preservada como observação independente.
- Estes indicadores foram calculados diretamente do CSV, não demonstram execução do banco nem do dashboard.
