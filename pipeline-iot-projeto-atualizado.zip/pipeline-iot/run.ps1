$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Test-Path '.env')) { Copy-Item '.env.example' '.env' }
if (-not (Test-Path '.venv/Scripts/python.exe')) { python -m venv .venv }
$py = Join-Path $PSScriptRoot '.venv/Scripts/python.exe'
& $py -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Falha na instalação de dependências' }
docker compose up -d --wait
if ($LASTEXITCODE -ne 0) { throw 'Falha ao iniciar PostgreSQL' }
& $py src/pipeline.py
if ($LASTEXITCODE -ne 0) { throw 'Falha ao importar CSV' }
& $py -m streamlit run src/dashboard.py
